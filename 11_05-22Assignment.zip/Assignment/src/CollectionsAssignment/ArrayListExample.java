//Write a Java program to create a new array list, add some elements (string) and print out the collection.

package CollectionsAssignment;

import java.util.*;

public class ArrayListExample {

	public static void main(String[] args) {
		
		ArrayList <String> a1 = new ArrayList <String>();
		
		a1.add("Raju");
		a1.add("Sachin");
		a1.add("Amit");
		a1.add("Battula");
		a1.add("Biswa");
		a1.add("Ansu");
		
		System.out.println("ArrayList : " + a1);
		//System.out.println("ArrayList Size : " + a1.size());
		
		
		

	}

}
